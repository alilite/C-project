﻿namespace Project_Final
{
    partial class FrmMoney
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMoney));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox_VND = new System.Windows.Forms.TextBox();
            this.textBox_GBP = new System.Windows.Forms.TextBox();
            this.textBox_USD = new System.Windows.Forms.TextBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.textBox_IRN = new System.Windows.Forms.TextBox();
            this.textBox_EUR = new System.Windows.Forms.TextBox();
            this.textBox_CAD = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox_inputValue = new System.Windows.Forms.TextBox();
            this.radioButtonIRN = new System.Windows.Forms.RadioButton();
            this.radioButtonGBP = new System.Windows.Forms.RadioButton();
            this.radioButtonEUR = new System.Windows.Forms.RadioButton();
            this.radioButtonUSD = new System.Windows.Forms.RadioButton();
            this.radioButtonCAD = new System.Windows.Forms.RadioButton();
            this.btn_Cnvr = new System.Windows.Forms.Button();
            this.btn_ReadDisplayTextFile = new System.Windows.Forms.Button();
            this.btn_Exit = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBox_VND);
            this.groupBox2.Controls.Add(this.textBox_GBP);
            this.groupBox2.Controls.Add(this.textBox_USD);
            this.groupBox2.Controls.Add(this.pictureBox11);
            this.groupBox2.Controls.Add(this.pictureBox10);
            this.groupBox2.Controls.Add(this.pictureBox9);
            this.groupBox2.Controls.Add(this.textBox_IRN);
            this.groupBox2.Controls.Add(this.textBox_EUR);
            this.groupBox2.Controls.Add(this.textBox_CAD);
            this.groupBox2.Controls.Add(this.pictureBox8);
            this.groupBox2.Controls.Add(this.pictureBox7);
            this.groupBox2.Controls.Add(this.pictureBox6);
            this.groupBox2.Location = new System.Drawing.Point(240, 148);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(518, 286);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "To";
            // 
            // textBox_VND
            // 
            this.textBox_VND.Location = new System.Drawing.Point(381, 231);
            this.textBox_VND.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_VND.Name = "textBox_VND";
            this.textBox_VND.ReadOnly = true;
            this.textBox_VND.Size = new System.Drawing.Size(100, 27);
            this.textBox_VND.TabIndex = 11;
            this.textBox_VND.TextChanged += new System.EventHandler(this.textBox_VND_TextChanged);
            // 
            // textBox_GBP
            // 
            this.textBox_GBP.Location = new System.Drawing.Point(381, 134);
            this.textBox_GBP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_GBP.Name = "textBox_GBP";
            this.textBox_GBP.ReadOnly = true;
            this.textBox_GBP.Size = new System.Drawing.Size(100, 27);
            this.textBox_GBP.TabIndex = 10;
            this.textBox_GBP.TextChanged += new System.EventHandler(this.textBox_GBP_TextChanged);
            // 
            // textBox_USD
            // 
            this.textBox_USD.Location = new System.Drawing.Point(381, 50);
            this.textBox_USD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_USD.Name = "textBox_USD";
            this.textBox_USD.ReadOnly = true;
            this.textBox_USD.Size = new System.Drawing.Size(100, 27);
            this.textBox_USD.TabIndex = 9;
            this.textBox_USD.TextChanged += new System.EventHandler(this.textBox_USD_TextChanged);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(264, 219);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(88, 41);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 8;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(264, 122);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(88, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 7;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(264, 39);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(88, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 6;
            this.pictureBox9.TabStop = false;
            // 
            // textBox_IRN
            // 
            this.textBox_IRN.Location = new System.Drawing.Point(123, 232);
            this.textBox_IRN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_IRN.Name = "textBox_IRN";
            this.textBox_IRN.ReadOnly = true;
            this.textBox_IRN.Size = new System.Drawing.Size(100, 27);
            this.textBox_IRN.TabIndex = 5;
            this.textBox_IRN.TextChanged += new System.EventHandler(this.textBox_IRN_TextChanged);
            // 
            // textBox_EUR
            // 
            this.textBox_EUR.Location = new System.Drawing.Point(123, 134);
            this.textBox_EUR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_EUR.Name = "textBox_EUR";
            this.textBox_EUR.ReadOnly = true;
            this.textBox_EUR.Size = new System.Drawing.Size(100, 27);
            this.textBox_EUR.TabIndex = 4;
            this.textBox_EUR.TextChanged += new System.EventHandler(this.textBox_EUR_TextChanged);
            // 
            // textBox_CAD
            // 
            this.textBox_CAD.Location = new System.Drawing.Point(123, 50);
            this.textBox_CAD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_CAD.Name = "textBox_CAD";
            this.textBox_CAD.ReadOnly = true;
            this.textBox_CAD.Size = new System.Drawing.Size(100, 27);
            this.textBox_CAD.TabIndex = 3;
            this.textBox_CAD.TextChanged += new System.EventHandler(this.textBox_CAD_TextChanged);
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(6, 219);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(85, 41);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(6, 122);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(85, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(6, 39);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(85, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.textBox_inputValue);
            this.groupBox1.Controls.Add(this.radioButtonIRN);
            this.groupBox1.Controls.Add(this.radioButtonGBP);
            this.groupBox1.Controls.Add(this.radioButtonEUR);
            this.groupBox1.Controls.Add(this.radioButtonUSD);
            this.groupBox1.Controls.Add(this.radioButtonCAD);
            this.groupBox1.Location = new System.Drawing.Point(12, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(200, 419);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "From";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(85, 291);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 40);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(85, 226);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 40);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(85, 158);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(60, 40);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(85, 96);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 40);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(85, 34);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(60, 40);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // textBox_inputValue
            // 
            this.textBox_inputValue.Location = new System.Drawing.Point(20, 371);
            this.textBox_inputValue.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_inputValue.Name = "textBox_inputValue";
            this.textBox_inputValue.Size = new System.Drawing.Size(154, 27);
            this.textBox_inputValue.TabIndex = 5;
            this.textBox_inputValue.TextChanged += new System.EventHandler(this.textBox_inputValue_TextChanged);
            // 
            // radioButtonIRN
            // 
            this.radioButtonIRN.AutoSize = true;
            this.radioButtonIRN.Location = new System.Drawing.Point(7, 306);
            this.radioButtonIRN.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonIRN.Name = "radioButtonIRN";
            this.radioButtonIRN.Size = new System.Drawing.Size(54, 24);
            this.radioButtonIRN.TabIndex = 4;
            this.radioButtonIRN.TabStop = true;
            this.radioButtonIRN.Text = "IRN";
            this.radioButtonIRN.UseVisualStyleBackColor = true;
            this.radioButtonIRN.CheckedChanged += new System.EventHandler(this.radioButtonIRN_CheckedChanged);
            // 
            // radioButtonGBP
            // 
            this.radioButtonGBP.AutoSize = true;
            this.radioButtonGBP.Location = new System.Drawing.Point(6, 241);
            this.radioButtonGBP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonGBP.Name = "radioButtonGBP";
            this.radioButtonGBP.Size = new System.Drawing.Size(57, 24);
            this.radioButtonGBP.TabIndex = 3;
            this.radioButtonGBP.TabStop = true;
            this.radioButtonGBP.Text = "GBP";
            this.radioButtonGBP.UseVisualStyleBackColor = true;
            this.radioButtonGBP.CheckedChanged += new System.EventHandler(this.radioButtonGBP_CheckedChanged);
            // 
            // radioButtonEUR
            // 
            this.radioButtonEUR.AutoSize = true;
            this.radioButtonEUR.Location = new System.Drawing.Point(7, 172);
            this.radioButtonEUR.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonEUR.Name = "radioButtonEUR";
            this.radioButtonEUR.Size = new System.Drawing.Size(57, 24);
            this.radioButtonEUR.TabIndex = 2;
            this.radioButtonEUR.TabStop = true;
            this.radioButtonEUR.Text = "EUR";
            this.radioButtonEUR.UseVisualStyleBackColor = true;
            this.radioButtonEUR.CheckedChanged += new System.EventHandler(this.radioButtonEUR_CheckedChanged);
            // 
            // radioButtonUSD
            // 
            this.radioButtonUSD.AutoSize = true;
            this.radioButtonUSD.Location = new System.Drawing.Point(7, 111);
            this.radioButtonUSD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonUSD.Name = "radioButtonUSD";
            this.radioButtonUSD.Size = new System.Drawing.Size(59, 24);
            this.radioButtonUSD.TabIndex = 1;
            this.radioButtonUSD.TabStop = true;
            this.radioButtonUSD.Text = "USD";
            this.radioButtonUSD.UseVisualStyleBackColor = true;
            this.radioButtonUSD.CheckedChanged += new System.EventHandler(this.radioButtonUSD_CheckedChanged);
            // 
            // radioButtonCAD
            // 
            this.radioButtonCAD.AutoSize = true;
            this.radioButtonCAD.Location = new System.Drawing.Point(6, 49);
            this.radioButtonCAD.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.radioButtonCAD.Name = "radioButtonCAD";
            this.radioButtonCAD.Size = new System.Drawing.Size(60, 24);
            this.radioButtonCAD.TabIndex = 0;
            this.radioButtonCAD.TabStop = true;
            this.radioButtonCAD.Text = "CAD";
            this.radioButtonCAD.UseVisualStyleBackColor = true;
            this.radioButtonCAD.CheckedChanged += new System.EventHandler(this.radioButtonCAD_CheckedChanged);
            // 
            // btn_Cnvr
            // 
            this.btn_Cnvr.Location = new System.Drawing.Point(18, 442);
            this.btn_Cnvr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Cnvr.Name = "btn_Cnvr";
            this.btn_Cnvr.Size = new System.Drawing.Size(138, 103);
            this.btn_Cnvr.TabIndex = 4;
            this.btn_Cnvr.Text = "&Convert from (choose a country)";
            this.btn_Cnvr.UseVisualStyleBackColor = true;
            this.btn_Cnvr.Click += new System.EventHandler(this.btn_Cnvr_Click);
            // 
            // btn_ReadDisplayTextFile
            // 
            this.btn_ReadDisplayTextFile.Location = new System.Drawing.Point(213, 442);
            this.btn_ReadDisplayTextFile.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_ReadDisplayTextFile.Name = "btn_ReadDisplayTextFile";
            this.btn_ReadDisplayTextFile.Size = new System.Drawing.Size(129, 103);
            this.btn_ReadDisplayTextFile.TabIndex = 6;
            this.btn_ReadDisplayTextFile.Text = "&Read and Display the Text File";
            this.btn_ReadDisplayTextFile.UseVisualStyleBackColor = true;
            this.btn_ReadDisplayTextFile.Click += new System.EventHandler(this.btn_ReadDisplayTextFile_Click);
            // 
            // btn_Exit
            // 
            this.btn_Exit.Location = new System.Drawing.Point(568, 442);
            this.btn_Exit.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Exit.Name = "btn_Exit";
            this.btn_Exit.Size = new System.Drawing.Size(112, 103);
            this.btn_Exit.TabIndex = 7;
            this.btn_Exit.Text = "E&xit";
            this.btn_Exit.UseVisualStyleBackColor = true;
            this.btn_Exit.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmMoney
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(758, 652);
            this.Controls.Add(this.btn_Exit);
            this.Controls.Add(this.btn_ReadDisplayTextFile);
            this.Controls.Add(this.btn_Cnvr);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmMoney";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MoneyExchange - Ali Bahiraei";
            this.Load += new System.EventHandler(this.FrmMoney_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox textBox_VND;
        private System.Windows.Forms.TextBox textBox_GBP;
        private System.Windows.Forms.TextBox textBox_USD;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.TextBox textBox_IRN;
        private System.Windows.Forms.TextBox textBox_EUR;
        private System.Windows.Forms.TextBox textBox_CAD;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox_inputValue;
        private System.Windows.Forms.RadioButton radioButtonIRN;
        private System.Windows.Forms.RadioButton radioButtonGBP;
        private System.Windows.Forms.RadioButton radioButtonEUR;
        private System.Windows.Forms.RadioButton radioButtonUSD;
        private System.Windows.Forms.RadioButton radioButtonCAD;
        private System.Windows.Forms.Button btn_Cnvr;
        private System.Windows.Forms.Button btn_ReadDisplayTextFile;
        private System.Windows.Forms.Button btn_Exit;
    }
}